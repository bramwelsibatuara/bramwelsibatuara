function calFahrenheit(celsius) {
  return (celsius * 9) / 5 + 32;
}

console.log(calFahrenheit(0));
console.log(calFahrenheit(20));
console.log(calFahrenheit(40));
