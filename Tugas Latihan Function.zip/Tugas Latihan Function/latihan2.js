function findSquare(number) {
  return number * number;
}

console.log(findSquare(2)); // Output: 4
console.log(findSquare(9)); // Output: 81
console.log(findSquare(15)); // Output: 225
