function rectangleArea(length, width) {
  const area = length * width;
  return `The area of the rectangle is ${area}`;
}

console.log(rectangleArea(10, 20)); // Output: The area of the rectangle is 200
console.log(rectangleArea(30, 30)); // Output: The area of the rectangle is 900
