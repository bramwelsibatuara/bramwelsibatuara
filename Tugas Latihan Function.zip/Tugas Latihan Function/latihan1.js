function displayMessage() {
  console.log("Hello World");
}

displayMessage();
