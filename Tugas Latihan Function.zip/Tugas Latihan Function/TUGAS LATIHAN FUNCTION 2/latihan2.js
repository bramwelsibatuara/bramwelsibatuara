function power(a, b) {
  return Math.pow(a, b);
}

console.log(power(7, 3)); // Output: 343
console.log(power(3, 3)); // Output: 27
console.log(power(4, 0.5)); // Output: 2
